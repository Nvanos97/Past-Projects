# flickit

## About

flickit is a web application created by Nathan Vanos, Mason Dellutri, Joshua Go that searches for photos using the flickr web API. Users can click on a photo and like/dislike it.

## Built Using
* JavaScript
* HTML
* CSS
* React
* Bootstrap

## Usage
Click on `feed_page.html` to start the application at the main page of flickit.